from flask import Flask

app = Flask(__name__)

@app.route("/")
def coucou():
    return "<h1>Salut ! Le serveur fonctionne !!</h1>"
